NEXORA STORE
Open index.html in any browser to preview the website.

This is a free static starter site. Product names/prices, payment gateway,
real inventory, shipping and domain can be connected later.
